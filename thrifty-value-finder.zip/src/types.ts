export interface ItemValuation {
  name: string;
  description: string;
  estimatedValue: string;
}